"use client";

import { Toaster } from "@/components/ui/toaster";

const AppMessage = () => {
  return <Toaster />;
};
export default AppMessage;
